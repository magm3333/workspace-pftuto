package ar.com.magm.model;

public class Zona {
	private int idZona;
	private String zona;

	public int getIdZona() {
		return idZona;
	}

	public String getZona() {
		return zona;
	}

	public void setIdZona(int idZona) {
		this.idZona = idZona;
	}

	public void setZona(String zona) {
		this.zona = zona;
	}
}
