package ar.com.magm.persistencia.dao;

import ar.com.magm.model.Zona;

public interface ZonaDAO extends GenericDAO<Zona, Integer> {

}
