package ar.com.magm.persistencia.dao.hibernateimpl;

import ar.com.magm.model.Zona;
import ar.com.magm.persistencia.dao.ZonaDAO;

public class ZonaDAOImplHibernate extends
		GenericDAOImplHibernate<Zona, Integer> implements ZonaDAO {

}
