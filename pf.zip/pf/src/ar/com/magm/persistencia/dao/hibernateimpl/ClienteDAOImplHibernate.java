package ar.com.magm.persistencia.dao.hibernateimpl;

import ar.com.magm.model.Cliente;
import ar.com.magm.persistencia.dao.ClienteDAO;

public class ClienteDAOImplHibernate extends
		GenericDAOImplHibernate<Cliente, Integer> implements ClienteDAO {

}
