package ar.com.magm.persistencia.dao;

import ar.com.magm.model.Cliente;

public interface ClienteDAO extends GenericDAO<Cliente, Integer> {

}
